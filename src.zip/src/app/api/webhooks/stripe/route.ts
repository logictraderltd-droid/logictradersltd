import { createAdminClient } from '@/lib/supabase';
import { NextResponse } from 'next/server';
import Stripe from 'stripe';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-06-20',
});

const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET!;

export async function POST(request: Request) {
  try {
    const payload = await request.text();
    const signature = request.headers.get('stripe-signature')!;

    let event: Stripe.Event;

    try {
      event = stripe.webhooks.constructEvent(payload, signature, webhookSecret);
    } catch (err: any) {
      console.error('Webhook signature verification failed:', err.message);
      return NextResponse.json(
        { error: 'Invalid signature' },
        { status: 400 }
      );
    }

    const supabase = createAdminClient();

    // Handle the event
    switch (event.type) {
      case 'payment_intent.succeeded': {
        const paymentIntent = event.data.object as Stripe.PaymentIntent;
        
        // Update payment status
        const { error: paymentError } = await supabase
          .from('payments')
          .update({
            status: 'completed',
            updated_at: new Date().toISOString(),
          })
          .eq('provider_payment_id', paymentIntent.id);

        if (paymentError) {
          console.error('Error updating payment:', paymentError);
        }

        // Update order status
        const { error: orderError } = await supabase
          .from('orders')
          .update({
            status: 'completed',
            updated_at: new Date().toISOString(),
          })
          .eq('id', paymentIntent.metadata.order_id);

        if (orderError) {
          console.error('Error updating order:', orderError);
        }

        // Grant access to the product (handled by database trigger)
        console.log('Payment succeeded, access granted for order:', paymentIntent.metadata.order_id);
        break;
      }

      case 'payment_intent.payment_failed': {
        const paymentIntent = event.data.object as Stripe.PaymentIntent;
        
        // Update payment status
        const { error: paymentError } = await supabase
          .from('payments')
          .update({
            status: 'failed',
            updated_at: new Date().toISOString(),
          })
          .eq('provider_payment_id', paymentIntent.id);

        if (paymentError) {
          console.error('Error updating payment:', paymentError);
        }

        // Update order status
        const { error: orderError } = await supabase
          .from('orders')
          .update({
            status: 'failed',
            updated_at: new Date().toISOString(),
          })
          .eq('id', paymentIntent.metadata.order_id);

        if (orderError) {
          console.error('Error updating order:', orderError);
        }

        console.log('Payment failed for order:', paymentIntent.metadata.order_id);
        break;
      }

      case 'payment_intent.canceled': {
        const paymentIntent = event.data.object as Stripe.PaymentIntent;
        
        // Update payment status
        const { error: paymentError } = await supabase
          .from('payments')
          .update({
            status: 'failed',
            updated_at: new Date().toISOString(),
          })
          .eq('provider_payment_id', paymentIntent.id);

        if (paymentError) {
          console.error('Error updating payment:', paymentError);
        }

        // Update order status
        const { error: orderError } = await supabase
          .from('orders')
          .update({
            status: 'failed',
            updated_at: new Date().toISOString(),
          })
          .eq('id', paymentIntent.metadata.order_id);

        if (orderError) {
          console.error('Error updating order:', orderError);
        }

        console.log('Payment canceled for order:', paymentIntent.metadata.order_id);
        break;
      }

      default:
        console.log(`Unhandled event type: ${event.type}`);
    }

    return NextResponse.json({ received: true });
  } catch (error: any) {
    console.error('Webhook error:', error);
    return NextResponse.json(
      { error: error.message || 'Webhook handler failed' },
      { status: 500 }
    );
  }
}
