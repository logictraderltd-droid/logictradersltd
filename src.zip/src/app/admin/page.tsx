"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  Users,
  ShoppingCart,
  TrendingUp,
  CreditCard,
  Package,
  Bell,
  Settings,
  LogOut,
  Plus,
  Edit,
  Trash2,
  TrendingUp as TrendingUpIcon,
} from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { createBrowserClient } from "@/lib/supabase";

interface AdminStats {
  totalUsers: number;
  totalRevenue: number;
  totalOrders: number;
  activeSubscriptions: number;
}

interface RecentOrder {
  id: string;
  user_email: string;
  product_name: string;
  amount: number;
  status: string;
  created_at: string;
}

interface RecentUser {
  id: string;
  email: string;
  role: string;
  created_at: string;
}

export default function AdminDashboard() {
  const router = useRouter();
  const { user, isAuthenticated, isAdmin, logout } = useAuth();
  const [stats, setStats] = useState<AdminStats>({
    totalUsers: 0,
    totalRevenue: 0,
    totalOrders: 0,
    activeSubscriptions: 0,
  });
  const [recentOrders, setRecentOrders] = useState<RecentOrder[]>([]);
  const [recentUsers, setRecentUsers] = useState<RecentUser[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("overview");

  // Redirect if not admin
  useEffect(() => {
    if (!isAuthenticated && !isLoading) {
      router.push("/login?redirect=/admin");
    } else if (isAuthenticated && !isAdmin) {
      router.push("/dashboard");
    }
  }, [isAuthenticated, isAdmin, isLoading, router]);

  // Fetch admin data
  useEffect(() => {
    if (!isAdmin) return;

    const fetchData = async () => {
      const supabase = createBrowserClient();

      try {
        // Fetch total users
        const { count: totalUsers } = await supabase
          .from("users")
          .select("*", { count: "exact", head: true });

        // Fetch total revenue
        const { data: revenueData } = await supabase
          .from("orders")
          .select("amount")
          .eq("status", "completed");

        const totalRevenue = revenueData?.reduce((sum, order) => sum + order.amount, 0) || 0;

        // Fetch total orders
        const { count: totalOrders } = await supabase
          .from("orders")
          .select("*", { count: "exact", head: true });

        // Fetch active subscriptions
        const { count: activeSubscriptions } = await supabase
          .from("subscriptions")
          .select("*", { count: "exact", head: true })
          .eq("status", "active")
          .gte("current_period_end", new Date().toISOString());

        setStats({
          totalUsers: totalUsers || 0,
          totalRevenue,
          totalOrders: totalOrders || 0,
          activeSubscriptions: activeSubscriptions || 0,
        });

        // Fetch recent orders
        const { data: ordersData } = await supabase
          .from("orders")
          .select(`
            *,
            product:products(name),
            user:users(email)
          `)
          .order("created_at", { ascending: false })
          .limit(5);

        setRecentOrders(
          ordersData?.map((order: any) => ({
            id: order.id,
            user_email: order.user?.email || "Unknown",
            product_name: order.product?.name || "Unknown",
            amount: order.amount,
            status: order.status,
            created_at: order.created_at,
          })) || []
        );

        // Fetch recent users
        const { data: usersData } = await supabase
          .from("users")
          .select("*")
          .order("created_at", { ascending: false })
          .limit(5);

        setRecentUsers(usersData || []);
      } catch (error) {
        console.error("Error fetching admin data:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [isAdmin]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-dark-950 flex items-center justify-center">
        <div className="spinner" />
      </div>
    );
  }

  if (!isAuthenticated || !isAdmin) {
    return null;
  }

  return (
    <div className="min-h-screen bg-dark-950">
      {/* Header */}
      <header className="bg-dark-900 border-b border-dark-800 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/admin" className="flex items-center space-x-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-gold-400 to-gold-600 flex items-center justify-center">
                <TrendingUpIcon className="w-5 h-5 text-dark-950" />
              </div>
              <span className="text-lg font-bold gold-gradient-text hidden sm:block">
                Admin Panel
              </span>
            </Link>

            <div className="flex items-center space-x-4">
              <span className="px-3 py-1 rounded-full bg-gold-500/20 text-gold-400 text-sm font-medium">
                Admin
              </span>
              <button
                onClick={logout}
                className="p-2 rounded-lg hover:bg-dark-800 text-gray-400 hover:text-red-400 transition-colors"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <nav className="space-y-2">
              <button
                onClick={() => setActiveTab("overview")}
                className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                  activeTab === "overview"
                    ? "bg-gold-500/10 text-gold-400"
                    : "text-gray-400 hover:bg-dark-800 hover:text-white"
                }`}
              >
                <TrendingUpIcon className="w-5 h-5" />
                <span>Overview</span>
              </button>
              <button
                onClick={() => setActiveTab("users")}
                className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                  activeTab === "users"
                    ? "bg-gold-500/10 text-gold-400"
                    : "text-gray-400 hover:bg-dark-800 hover:text-white"
                }`}
              >
                <Users className="w-5 h-5" />
                <span>Users</span>
              </button>
              <button
                onClick={() => setActiveTab("products")}
                className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                  activeTab === "products"
                    ? "bg-gold-500/10 text-gold-400"
                    : "text-gray-400 hover:bg-dark-800 hover:text-white"
                }`}
              >
                <Package className="w-5 h-5" />
                <span>Products</span>
              </button>
              <button
                onClick={() => setActiveTab("orders")}
                className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                  activeTab === "orders"
                    ? "bg-gold-500/10 text-gold-400"
                    : "text-gray-400 hover:bg-dark-800 hover:text-white"
                }`}
              >
                <ShoppingCart className="w-5 h-5" />
                <span>Orders</span>
              </button>
              <button
                onClick={() => setActiveTab("signals")}
                className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                  activeTab === "signals"
                    ? "bg-gold-500/10 text-gold-400"
                    : "text-gray-400 hover:bg-dark-800 hover:text-white"
                }`}
              >
                <Bell className="w-5 h-5" />
                <span>Signals</span>
              </button>
              <button
                onClick={() => setActiveTab("settings")}
                className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                  activeTab === "settings"
                    ? "bg-gold-500/10 text-gold-400"
                    : "text-gray-400 hover:bg-dark-800 hover:text-white"
                }`}
              >
                <Settings className="w-5 h-5" />
                <span>Settings</span>
              </button>
            </nav>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {activeTab === "overview" && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                {/* Welcome Banner */}
                <div className="dark-card p-6 bg-gradient-to-r from-gold-500/10 to-transparent border-gold-500/30">
                  <h1 className="text-2xl font-bold mb-2">
                    Admin Dashboard
                  </h1>
                  <p className="text-gray-400">
                    Manage your platform, users, and products from one place.
                  </p>
                </div>

                {/* Stats Grid */}
                <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="dark-card p-6">
                    <div className="flex items-center space-x-3 mb-2">
                      <Users className="w-5 h-5 text-gold-400" />
                      <span className="text-sm text-gray-400">Total Users</span>
                    </div>
                    <p className="text-2xl font-bold">{stats.totalUsers}</p>
                  </div>
                  <div className="dark-card p-6">
                    <div className="flex items-center space-x-3 mb-2">
                      <CreditCard className="w-5 h-5 text-gold-400" />
                      <span className="text-sm text-gray-400">Revenue</span>
                    </div>
                    <p className="text-2xl font-bold">${stats.totalRevenue.toFixed(2)}</p>
                  </div>
                  <div className="dark-card p-6">
                    <div className="flex items-center space-x-3 mb-2">
                      <ShoppingCart className="w-5 h-5 text-gold-400" />
                      <span className="text-sm text-gray-400">Total Orders</span>
                    </div>
                    <p className="text-2xl font-bold">{stats.totalOrders}</p>
                  </div>
                  <div className="dark-card p-6">
                    <div className="flex items-center space-x-3 mb-2">
                      <Bell className="w-5 h-5 text-gold-400" />
                      <span className="text-sm text-gray-400">Active Subs</span>
                    </div>
                    <p className="text-2xl font-bold">{stats.activeSubscriptions}</p>
                  </div>
                </div>

                {/* Recent Activity */}
                <div className="grid md:grid-cols-2 gap-6">
                  {/* Recent Orders */}
                  <div className="dark-card p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-bold">Recent Orders</h3>
                      <button
                        onClick={() => setActiveTab("orders")}
                        className="text-sm text-gold-400 hover:text-gold-300"
                      >
                        View All
                      </button>
                    </div>
                    <div className="space-y-3">
                      {recentOrders.map((order) => (
                        <div
                          key={order.id}
                          className="flex items-center justify-between p-3 bg-dark-800 rounded-lg"
                        >
                          <div>
                            <p className="font-medium text-sm">{order.product_name}</p>
                            <p className="text-xs text-gray-500">{order.user_email}</p>
                          </div>
                          <div className="text-right">
                            <p className="font-medium">${order.amount}</p>
                            <span
                              className={`text-xs ${
                                order.status === "completed"
                                  ? "text-green-400"
                                  : order.status === "pending"
                                  ? "text-yellow-400"
                                  : "text-red-400"
                              }`}
                            >
                              {order.status}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Recent Users */}
                  <div className="dark-card p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-bold">Recent Users</h3>
                      <button
                        onClick={() => setActiveTab("users")}
                        className="text-sm text-gold-400 hover:text-gold-300"
                      >
                        View All
                      </button>
                    </div>
                    <div className="space-y-3">
                      {recentUsers.map((user) => (
                        <div
                          key={user.id}
                          className="flex items-center justify-between p-3 bg-dark-800 rounded-lg"
                        >
                          <div>
                            <p className="font-medium text-sm">{user.email}</p>
                            <p className="text-xs text-gray-500 capitalize">
                              {user.role}
                            </p>
                          </div>
                          <span className="text-xs text-gray-500">
                            {new Date(user.created_at).toLocaleDateString()}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === "users" && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold">User Management</h2>
                </div>
                <div className="dark-card p-12 text-center">
                  <Users className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">User Management</h3>
                  <p className="text-gray-500 mb-4">
                    Full user management interface coming soon
                  </p>
                </div>
              </motion.div>
            )}

            {activeTab === "products" && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold">Product Management</h2>
                  <button className="gold-button flex items-center space-x-2">
                    <Plus className="w-4 h-4" />
                    <span>Add Product</span>
                  </button>
                </div>
                <div className="dark-card p-12 text-center">
                  <Package className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">Product Management</h3>
                  <p className="text-gray-500 mb-4">
                    Full product management interface coming soon
                  </p>
                </div>
              </motion.div>
            )}

            {activeTab === "orders" && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <h2 className="text-2xl font-bold mb-6">Order Management</h2>
                <div className="dark-card p-12 text-center">
                  <ShoppingCart className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">Order Management</h3>
                  <p className="text-gray-500 mb-4">
                    Full order management interface coming soon
                  </p>
                </div>
              </motion.div>
            )}

            {activeTab === "signals" && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold">Signal Management</h2>
                  <button className="gold-button flex items-center space-x-2">
                    <Plus className="w-4 h-4" />
                    <span>Add Signal</span>
                  </button>
                </div>
                <div className="dark-card p-12 text-center">
                  <Bell className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">Signal Management</h3>
                  <p className="text-gray-500 mb-4">
                    Full signal management interface coming soon
                  </p>
                </div>
              </motion.div>
            )}

            {activeTab === "settings" && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <h2 className="text-2xl font-bold mb-6">Platform Settings</h2>
                <div className="dark-card p-12 text-center">
                  <Settings className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">Settings</h3>
                  <p className="text-gray-500 mb-4">
                    Platform settings interface coming soon
                  </p>
                </div>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
