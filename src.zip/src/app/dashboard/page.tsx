"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  BookOpen,
  Bell,
  Bot,
  CreditCard,
  User,
  LogOut,
  Play,
  TrendingUp,
  Clock,
  ChevronRight,
  Lock,
} from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { createBrowserClient } from "@/lib/supabase";
import { Course, Subscription, TradingBot, TradingSignal, Order } from "@/types";

interface DashboardData {
  courses: Course[];
  subscriptions: Subscription[];
  bots: TradingBot[];
  recentSignals: TradingSignal[];
  paymentHistory: Order[];
}

export default function DashboardPage() {
  const router = useRouter();
  const { user, profile, isAuthenticated, isLoading: authLoading, logout } = useAuth();
  const [data, setData] = useState<DashboardData>({
    courses: [],
    subscriptions: [],
    bots: [],
    recentSignals: [],
    paymentHistory: [],
  });
  const [isLoading, setIsLoading] = useState(false); // ✅ Changed to false initially
  const [activeTab, setActiveTab] = useState("overview");
  const [error, setError] = useState<string | null>(null);

  // ✅ FIX: Better redirect logic with logging
  useEffect(() => {
    console.log('🔒 Dashboard auth check:', { authLoading, isAuthenticated });
    
    if (!authLoading && !isAuthenticated) {
      console.log('❌ Not authenticated, redirecting to login');
      router.push("/login?redirect=/dashboard");
    }
  }, [authLoading, isAuthenticated, router]);

  // ✅ FIX: Fetch dashboard data with better error handling
  useEffect(() => {
    // Don't fetch if still checking auth or not authenticated
    if (authLoading || !isAuthenticated || !user?.id) {
      console.log('⏸️ Skipping data fetch:', { authLoading, isAuthenticated, hasUser: !!user?.id });
      return;
    }

    const fetchData = async () => {
      console.log('📊 Fetching dashboard data for user:', user.id);
      setIsLoading(true);
      setError(null);
      const supabase = createBrowserClient();

      try {
        // Fetch user's purchased courses through user_access
        const { data: courseAccess, error: courseAccessError } = await supabase
          .from("user_access")
          .select("product_id")
          .eq("user_id", user.id)
          .eq("product_type", "course")
          .eq("is_active", true);

        if (courseAccessError) {
          console.error('❌ Error fetching course access:', courseAccessError);
        }

        const courseIds = courseAccess?.map((a) => a.product_id) || [];

        let courses: Course[] = [];
        if (courseIds.length > 0) {
          const { data: courseData, error: courseError } = await supabase
            .from("products")
            .select("*")
            .in("id", courseIds);
          
          if (courseError) {
            console.error('❌ Error fetching courses:', courseError);
          }
          courses = courseData || [];
        }

        // Fetch active subscriptions
        const { data: subscriptionsData, error: subsError } = await supabase
          .from("subscriptions")
          .select(`
            *,
            plan:products(*)
          `)
          .eq("user_id", user.id)
          .eq("status", "active")
          .gte("current_period_end", new Date().toISOString());

        if (subsError) {
          console.error('❌ Error fetching subscriptions:', subsError);
        }

        // Fetch purchased bots
        const { data: botAccess, error: botAccessError } = await supabase
          .from("user_access")
          .select("product_id")
          .eq("user_id", user.id)
          .eq("product_type", "bot")
          .eq("is_active", true);

        if (botAccessError) {
          console.error('❌ Error fetching bot access:', botAccessError);
        }

        const botIds = botAccess?.map((a) => a.product_id) || [];

        let bots: TradingBot[] = [];
        if (botIds.length > 0) {
          const { data: botData, error: botError } = await supabase
            .from("products")
            .select("*")
            .in("id", botIds);
          
          if (botError) {
            console.error('❌ Error fetching bots:', botError);
          }
          bots = botData || [];
        }

        // Fetch recent signals if user has active subscription
        let signals: TradingSignal[] = [];
        if (subscriptionsData && subscriptionsData.length > 0) {
          const planIds = subscriptionsData.map((s) => s.plan_id);
          const { data: signalsData, error: signalsError } = await supabase
            .from("signals")
            .select("*")
            .in("plan_id", planIds)
            .order("created_at", { ascending: false })
            .limit(5);
          
          if (signalsError) {
            console.error('❌ Error fetching signals:', signalsError);
          }
          signals = signalsData || [];
        }

        // Fetch payment history
        const { data: ordersData, error: ordersError } = await supabase
          .from("orders")
          .select(`
            *,
            product:products(*)
          `)
          .eq("user_id", user.id)
          .order("created_at", { ascending: false })
          .limit(5);

        if (ordersError) {
          console.error('❌ Error fetching orders:', ordersError);
        }

        setData({
          courses,
          subscriptions: subscriptionsData || [],
          bots,
          recentSignals: signals,
          paymentHistory: ordersData || [],
        });

        console.log('✅ Dashboard data loaded successfully');
      } catch (error) {
        console.error("❌ Error fetching dashboard data:", error);
        setError("Failed to load dashboard data. Please refresh the page.");
      } finally {
        setIsLoading(false);
      }
    };

    // Add a small delay to ensure auth is fully settled
    const timer = setTimeout(() => {
      fetchData();
    }, 100);

    return () => clearTimeout(timer);
  }, [user?.id, authLoading, isAuthenticated]);

  // ✅ Show loading spinner while checking auth
  if (authLoading) {
    console.log('⏳ Auth loading...');
    return (
      <div className="min-h-screen bg-dark-950 flex items-center justify-center">
        <div className="text-center">
          <div className="spinner mb-4" />
          <p className="text-gray-400">Loading...</p>
        </div>
      </div>
    );
  }

  // ✅ Don't render anything if not authenticated (redirect is happening)
  if (!isAuthenticated) {
    console.log('🚫 Not authenticated, not rendering dashboard');
    return null;
  }

  const hasActiveSubscription = data.subscriptions.length > 0;

  return (
    <div className="min-h-screen bg-dark-950">
      {/* Header */}
      <header className="bg-dark-900 border-b border-dark-800 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-gold-400 to-gold-600 flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-dark-950" />
              </div>
              <span className="text-lg font-bold gold-gradient-text hidden sm:block">
                LOGICTRADERSLTD
              </span>
            </Link>

            <div className="flex items-center space-x-4">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-medium text-white">
                  {profile?.first_name || 'User'} {profile?.last_name || ''}
                </p>
                <p className="text-xs text-gray-500">{user?.email}</p>
              </div>
              <button
                onClick={logout}
                className="p-2 rounded-lg hover:bg-dark-800 text-gray-400 hover:text-red-400 transition-colors"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* ✅ Show error if data fetch failed */}
        {error && (
          <div className="mb-6 p-4 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400">
            {error}
          </div>
        )}

        {/* ✅ Show loading overlay while fetching data */}
        {isLoading && (
          <div className="mb-6 flex items-center justify-center p-4 bg-dark-900 rounded-lg">
            <div className="spinner mr-3" />
            <span className="text-gray-400">Loading your data...</span>
          </div>
        )}

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <nav className="space-y-2">
              <button
                onClick={() => setActiveTab("overview")}
                className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                  activeTab === "overview"
                    ? "bg-gold-500/10 text-gold-400"
                    : "text-gray-400 hover:bg-dark-800 hover:text-white"
                }`}
              >
                <TrendingUp className="w-5 h-5" />
                <span>Overview</span>
              </button>
              <button
                onClick={() => setActiveTab("courses")}
                className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                  activeTab === "courses"
                    ? "bg-gold-500/10 text-gold-400"
                    : "text-gray-400 hover:bg-dark-800 hover:text-white"
                }`}
              >
                <BookOpen className="w-5 h-5" />
                <span>My Courses</span>
                {data.courses.length > 0 && (
                  <span className="ml-auto bg-gold-500 text-dark-950 text-xs font-bold px-2 py-0.5 rounded-full">
                    {data.courses.length}
                  </span>
                )}
              </button>
              <button
                onClick={() => setActiveTab("signals")}
                className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                  activeTab === "signals"
                    ? "bg-gold-500/10 text-gold-400"
                    : "text-gray-400 hover:bg-dark-800 hover:text-white"
                }`}
              >
                <Bell className="w-5 h-5" />
                <span>Signals</span>
                {hasActiveSubscription && (
                  <span className="ml-auto bg-green-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                    Active
                  </span>
                )}
              </button>
              <button
                onClick={() => setActiveTab("bots")}
                className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                  activeTab === "bots"
                    ? "bg-gold-500/10 text-gold-400"
                    : "text-gray-400 hover:bg-dark-800 hover:text-white"
                }`}
              >
                <Bot className="w-5 h-5" />
                <span>My Bots</span>
                {data.bots.length > 0 && (
                  <span className="ml-auto bg-gold-500 text-dark-950 text-xs font-bold px-2 py-0.5 rounded-full">
                    {data.bots.length}
                  </span>
                )}
              </button>
              <button
                onClick={() => setActiveTab("payments")}
                className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                  activeTab === "payments"
                    ? "bg-gold-500/10 text-gold-400"
                    : "text-gray-400 hover:bg-dark-800 hover:text-white"
                }`}
              >
                <CreditCard className="w-5 h-5" />
                <span>Payments</span>
              </button>
              <button
                onClick={() => setActiveTab("profile")}
                className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                  activeTab === "profile"
                    ? "bg-gold-500/10 text-gold-400"
                    : "text-gray-400 hover:bg-dark-800 hover:text-white"
                }`}
              >
                <User className="w-5 h-5" />
                <span>Profile</span>
              </button>
            </nav>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {activeTab === "overview" && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                {/* Welcome Banner */}
                <div className="dark-card p-6 bg-gradient-to-r from-gold-500/10 to-transparent border-gold-500/30">
                  <h1 className="text-2xl font-bold mb-2">
                    Welcome back, {profile?.first_name || 'Trader'}!
                  </h1>
                  <p className="text-gray-400">
                    Here&apos;s an overview of your trading journey with us.
                  </p>
                </div>

                {/* Stats Grid */}
                <div className="grid sm:grid-cols-3 gap-4">
                  <div className="dark-card p-6">
                    <div className="flex items-center space-x-3 mb-2">
                      <BookOpen className="w-5 h-5 text-gold-400" />
                      <span className="text-sm text-gray-400">Courses</span>
                    </div>
                    <p className="text-2xl font-bold">{data.courses.length}</p>
                  </div>
                  <div className="dark-card p-6">
                    <div className="flex items-center space-x-3 mb-2">
                      <Bell className="w-5 h-5 text-gold-400" />
                      <span className="text-sm text-gray-400">Active Subscriptions</span>
                    </div>
                    <p className="text-2xl font-bold">{data.subscriptions.length}</p>
                  </div>
                  <div className="dark-card p-6">
                    <div className="flex items-center space-x-3 mb-2">
                      <Bot className="w-5 h-5 text-gold-400" />
                      <span className="text-sm text-gray-400">Trading Bots</span>
                    </div>
                    <p className="text-2xl font-bold">{data.bots.length}</p>
                  </div>
                </div>

                {/* Rest of overview content... */}
                <div className="grid md:grid-cols-2 gap-6">
                  {/* Recent Signals */}
                  <div className="dark-card p-6">
                    <h3 className="text-lg font-bold mb-4">Recent Signals</h3>
                    {hasActiveSubscription ? (
                      data.recentSignals.length > 0 ? (
                        <div className="space-y-3">
                          {data.recentSignals.map((signal) => (
                            <div
                              key={signal.id}
                              className="flex items-center justify-between p-3 bg-dark-800 rounded-lg"
                            >
                              <div>
                                <p className="font-medium">{signal.symbol}</p>
                                <p className="text-xs text-gray-500">
                                  {new Date(signal.created_at).toLocaleDateString()}
                                </p>
                              </div>
                              <span
                                className={`px-2 py-1 rounded text-xs font-medium ${
                                  signal.direction === "buy"
                                    ? "bg-green-500/20 text-green-400"
                                    : "bg-red-500/20 text-red-400"
                                }`}
                              >
                                {signal.direction.toUpperCase()}
                              </span>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-gray-500 text-sm">No recent signals</p>
                      )
                    ) : (
                      <div className="text-center py-6">
                        <Lock className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                        <p className="text-gray-500 text-sm mb-3">
                          Subscribe to a signal plan to view trading signals
                        </p>
                        <Link
                          href="/signals"
                          className="text-gold-400 text-sm hover:text-gold-300"
                        >
                          View Plans →
                        </Link>
                      </div>
                    )}
                  </div>

                  {/* Recent Payments */}
                  <div className="dark-card p-6">
                    <h3 className="text-lg font-bold mb-4">Recent Payments</h3>
                    {data.paymentHistory.length > 0 ? (
                      <div className="space-y-3">
                        {data.paymentHistory.map((order) => (
                          <div
                            key={order.id}
                            className="flex items-center justify-between p-3 bg-dark-800 rounded-lg"
                          >
                            <div>
                              <p className="font-medium text-sm">
                                {order.product?.name || "Unknown Product"}
                              </p>
                              <p className="text-xs text-gray-500">
                                {new Date(order.created_at).toLocaleDateString()}
                              </p>
                            </div>
                            <div className="text-right">
                              <p className="font-medium">${order.amount}</p>
                              <span
                                className={`text-xs ${
                                  order.status === "completed"
                                    ? "text-green-400"
                                    : order.status === "pending"
                                    ? "text-yellow-400"
                                    : "text-red-400"
                                }`}
                              >
                                {order.status}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-gray-500 text-sm">No payment history</p>
                    )}
                  </div>
                </div>
              </motion.div>
            )}

            {/* ... Rest of your tabs remain the same ... */}
            {/* I'm keeping the rest of the code the same for brevity */}
            {/* Just copy the courses, signals, bots, payments, and profile tabs from your original */}
          </div>
        </div>
      </div>
    </div>
  );
}